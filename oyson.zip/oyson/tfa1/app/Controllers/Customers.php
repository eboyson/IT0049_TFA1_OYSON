<?php

namespace App\Controllers;

class Customers extends BaseController
{
    public function index()
    {
        $data['customers'] = [
            [
                'fullname' => 'John Doe',
                'email' => 'john@example.com',
                'phone' => '09123456789'
            ],
            [
                'fullname' => 'Jane Smith',
                'email' => 'jane@example.com',
                'phone' => '09234567890'
            ],
            [
                'fullname' => 'Michael Cruz',
                'email' => 'michael@example.com',
                'phone' => '09345678901'
            ],
            [
                'fullname' => 'Sarah Lee',
                'email' => 'sarah@example.com',
                'phone' => '09456789012'
            ],
            [
                'fullname' => 'David Reyes',
                'email' => 'david@example.com',
                'phone' => '09567890123'
            ]
        ];

        return view('customers', $data);
    }
}