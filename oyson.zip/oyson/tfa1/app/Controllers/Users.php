<?php

namespace App\Controllers;

class Users extends BaseController
{
    public function index()
    {
        $data['users'] = [
            [
                'username' => 'admin01',
                'fullname' => 'Admin User',
                'role' => 'Administrator'
            ],
            [
                'username' => 'cashier01',
                'fullname' => 'Maria Santos',
                'role' => 'Cashier'
            ],
            [
                'username' => 'staff01',
                'fullname' => 'Juan Cruz',
                'role' => 'Staff'
            ],
            [
                'username' => 'staff02',
                'fullname' => 'Ana Reyes',
                'role' => 'Staff'
            ],
            [
                'username' => 'manager01',
                'fullname' => 'Paul Garcia',
                'role' => 'Manager'
            ]
        ];

        return view('users', $data);
    }
}
