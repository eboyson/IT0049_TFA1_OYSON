<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
</head>
<body>

<h1>Welcome to the POS System</h1>

/Home</a> |
<aboutAbout</a> |
<austomersCustomers</a> |
<a href="/s</a>

<p>This is the landing page.</p>

</body>
</html>