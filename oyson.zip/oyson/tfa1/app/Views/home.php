<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
</head>
<body>

<h1>Welcome to the POS System</h1>

<nav>
    <a href="/"> Home </a> |
    <a href="about"> About </a> |
    <a href="customers"> Customers </a> |
    <a href="users"> Users </a>
</nav>
 

<p>This is the landing page.</p>

</body>
</html>